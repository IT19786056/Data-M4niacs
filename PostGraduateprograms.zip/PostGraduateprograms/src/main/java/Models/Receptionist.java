
package Models;

public class Receptionist {
    public int RID;
    public String R_name;
    public int Phone_no;
    public String R_email_address;
    
public String provide_course_defults()
{}
public String Recommend_courses()
{}
}
